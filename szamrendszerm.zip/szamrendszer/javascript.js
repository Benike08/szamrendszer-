// TÍZESBŐL--------------------------------------------------------------------------------------------------------
const tizenhatos = ["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"]
const kettes = ["0","1"]
const nyolcas = ["0","1","2","3","4","5","6","7"]
const tizes = ["0","1","2","3","4","5","6","7","8","9"]
function binaris(){
    atirt = ""
    while (beker != 0){    
        atirt = beker % 2 + atirt;
        beker = (beker - beker % 2) / 2;
    } document.getElementById("kijelzo").innerText = atirt
}
function oktalis() {
    atirt = ""
    while (beker != 0){    
        atirt = beker % 8 + atirt;
        beker = (beker - beker % 8) / 8;
    } document.getElementById("kijelzo").innerText = atirt
}
function hexadecimalis() {
    atirt = ""
    while (beker != 0){
        if (beker % 16 <= 9){
            atirt = beker % 16 + atirt;
            beker = (beker - beker % 16) / 16;
        } else if (beker % 16 == 10){
            atirt = "A" + atirt;
            beker = (beker - 10) / 16;
        } else if (beker % 16 == 11){
            atirt = "B" + atirt;
            beker = (beker - 11) / 16;
        } else if (beker % 16 == 12){
            atirt = "C" + atirt;
            beker = (beker - 12) / 16;
        } else if (beker % 16 == 13){
            atirt = "D" + atirt;
            beker = (beker - 13) / 16;
        } else if (beker % 16 == 14){
            atirt = "E" + atirt;
            beker = (beker - 14) / 16;
        } else if (beker % 16 == 15){
            atirt = "F" + atirt;
            beker = (beker - 15) / 16;
        }
    } document.getElementById("kijelzo").innerText = atirt
}
// TÍZESBE---------------------------------------------------------------------------------------------------------
function binarisBOL(){
    beker = document.getElementById("bemenet").value;
    atirt = 0;
    hossz = parseInt(beker.length) - 1;
    for (let i = 0; i < beker.length; i++){
        szamjegy = beker[i];
        if (szamjegy == 1){
        atirt += Math.pow(2, hossz);
        } 
        hossz -= 1;
    }
    return atirt
}
function oktalisBOL() {
    beker = document.getElementById("bemenet").value;
    atirt = 0;
    hossz = parseInt(beker.length) - 1;
    for (let i = 0; i < beker.length; i++){
        szamjegy = beker[i];
        atirt += szamjegy * (Math.pow(8, hossz));
        hossz -= 1;
    } 
    return atirt
}
function hexadecimalisBOL() {
    beker = document.getElementById("bemenet").value;
    atirt = 0;
    hossz = parseInt(beker.length) - 1;
    for (let i = 0; i < beker.length; i++){
        szamjegy = beker[i];
        if (szamjegy <= 9){
            atirt += szamjegy * (Math.pow(16, hossz));
        } else if (szamjegy == "A"){
            atirt += 10 * (Math.pow(16, hossz));
        } else if (szamjegy == "B"){
            atirt += 11 * (Math.pow(16, hossz));
        } else if (szamjegy == "C"){
            atirt += 12 * (Math.pow(16, hossz));
        } else if (szamjegy == "D"){
            atirt += 13 * (Math.pow(16, hossz));
        } else if (szamjegy == "E"){
            atirt += 14 * (Math.pow(16, hossz));
        } else if (szamjegy == "F"){
            atirt += 15 * (Math.pow(16, hossz));
        }
        hossz -= 1;
    } 
    return atirt
}
function szamol(){
    if (document.getElementById("amibol").value == "binaris"){
        beker = binarisBOL();
    } else if (document.getElementById("amibol").value == "oktalis"){
        beker = oktalisBOL();
    } else if (document.getElementById("amibol").value == "decimalis"){
        beker = document.getElementById("bemenet").value
    } else if (document.getElementById("amibol").value == "hexadecimalis"){
        beker = hexadecimalisBOL();
    }
    if (document.getElementById("amibe").value == "binaris") {
        binaris()
    } else if (document.getElementById("amibe").value == "oktalis"){
        oktalis()
    } else if (document.getElementById("amibe").value == "decimalis"){
        document.getElementById("kijelzo").innerText = beker
    } else if (document.getElementById("amibe").value == "hexadecimalis"){
        hexadecimalis()
    }
}
function main(){
    beker = document.getElementById("bemenet").value;
    if (document.getElementById("amibol").value == "binaris") {
        for (let i = 0; i < beker.length; i++){
            if (kettes.includes(beker[i])){
                continue
            } else {
                window.alert("Érvényes értéket adj meg! (a használható karakterek: " + kettes + ")")
                document.getElementById("kijelzo").innerText = null;
                return
            }
    }
    } else if (document.getElementById("amibol").value == "oktalis") {
        for (let i = 0; i < beker.length; i++){
            if (nyolcas.includes(beker[i])){
                continue
            } else {
                window.alert("Érvényes értéket adj meg! (a használható karakterek: " + nyolcas + ")")
                document.getElementById("kijelzo").innerText = null;
                return
            }
    }
    } else if (document.getElementById("amibol").value == "decimalis") {
        for (let i = 0; i < beker.length; i++){
            if (tizes.includes(beker[i])){
                continue
            } else {
                window.alert("Érvényes értéket adj meg! (a használható karakterek: " + tizes + ")")
                document.getElementById("kijelzo").innerText = null;
                return
            }
    }
    } else if (document.getElementById("amibol").value == "hexadecimalis") {
        for (let i = 0; i < beker.length; i++){
            if (tizenhatos.includes(beker[i])){
                continue
            } else {
                window.alert("Érvényes értéket adj meg! (a használható karakterek: " + tizenhatos + ")")
                document.getElementById("kijelzo").innerText = null;
                return
            }
    }
    } szamol()
}

