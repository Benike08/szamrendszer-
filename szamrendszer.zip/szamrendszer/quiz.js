const quizQuestions = [
    { question: "Mi a 25 decimális szám bináris alakja?", answer: "11001" },
    { question: "Mi a 1011 bináris szám decimális alakja?", answer: "11" },
    { question: "Mi a 64 decimális szám hexadecimális alakja?", answer: "40" },
    { question: "Mi a 2A hexadecimális szám decimális alakja?", answer: "42" },
    { question: "Mi a 73 decimális szám oktális alakja?", answer: "111" },
    { question: "Mi a 57 oktális szám decimális alakja?", answer: "47" },
    { question: "Mi a 101010 bináris szám hexadecimális alakja?", answer: "2A" },
    { question: "Mi a 3F hexadecimális szám bináris alakja?", answer: "111111" },
    { question: "Mi a 100 oktális szám decimális alakja?", answer: "64" },
    { question: "Mi a 1000000 bináris szám decimális alakja?", answer: "64" },
    { question: "Mi a 1F hexadecimális szám decimális alakja?", answer: "31" },
    { question: "Mi a 77 oktális szám bináris alakja?", answer: "111111" },
    { question: "Mi a 255 decimális szám bináris alakja?", answer: "11111111" },
    { question: "Mi a 255 decimális szám hexadecimális alakja?", answer: "FF" },
    { question: "Mi a 377 oktális szám decimális alakja?", answer: "255" },
    { question: "Mi a 1101 bináris szám decimális alakja?", answer: "13" },
    { question: "Mi a 14 hexadecimális szám bináris alakja?", answer: "10100" },
    { question: "Mi a 31 decimális szám hexadecimális alakja?", answer: "1F" },
    { question: "Mi a 77 oktális szám hexadecimális alakja?", answer: "3F" },
    { question: "Mi a 11111111 bináris szám decimális alakja?", answer: "255" }
  ];
  
  function startQuiz() {
    let score = 0;
    quizQuestions.forEach((q, index) => {
      let userAnswer = prompt(`${index + 1}. kérdés: ${q.question}`);
      if (userAnswer.trim().toUpperCase() === q.answer.toUpperCase()) {
        alert("Helyes!");
        score++;
      } else {
        alert(`Rossz válasz! A helyes megoldás: ${q.answer}`);
      }
    });
    alert(`A kvíz véget ért! Az eredményed: ${score} / ${quizQuestions.length}`);
  }